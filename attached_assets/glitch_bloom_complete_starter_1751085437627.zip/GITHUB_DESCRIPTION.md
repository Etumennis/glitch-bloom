# 🌸 Glitch Bloom

A surreal, glitch-themed pixel garden that evolves in real-time using live moon phases and weather data. Players uncover hidden lore echoes, trigger rare mutations, and grow a mysterious bloom to access a forgotten archive.

Built with Flask and JavaScript. Replit-ready. Designed for chill ambiance + secret discovery.

